import data from "../f1/index1.js"
import { uName } from "../f1/index1.js"
import { y2 } from "../f1/index1.js"
import { tamater } from "../f1/index1.js"
console.log(data)
console.log(uName, y2)
tamater()