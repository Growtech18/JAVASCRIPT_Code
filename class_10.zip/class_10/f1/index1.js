const data = 10;
export default data;
export const uName = "Jagmohan "
var y = 20;
// export default y;//this is invalid multiple export default is not allowed in same file/module
export var y2 = 78;

export  function tamater() {
    console.log("lal tamater lal tamater")
}